How to run Q3.java file?
1. In terminal enter: javac Q3.java
2. To run the program: java Q3

Output:
First text is the Plain text of Q3 A part

Second is the sequence of alphabets with frequency count of the encrypted text in part A.

Third is the plain text of Q3 B part.